const express = require("express");
const account = require("./routes/account");
const barang = require("./routes/barang");
const cart = require("./routes/cart");
const review = require("./routes/review");
const periksa = require("./routes/periksa");
const transaksi = require("./routes/transaksi");
const app = express();

app.use(express.urlencoded({
    extended: true
}));

app.use("/api/account", account);
app.use("/api/barang", barang);
app.use("/api/cart", cart);
app.use("/api/review", review);
app.use("/api/periksa", periksa);
app.use("/api/transaksi", transaksi);

app.listen(3000, function () {
    console.log("listening to port 3000");
});