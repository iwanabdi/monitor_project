const express = require("express");
const router = express.Router();
const jwt = require("jsonwebtoken");
const m = require("../middlewares");
const {
    executeQuery,
    sendRequest
} = require("../util");

router.post("/register", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

router.post("/login", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

router.put("/change-password", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

module.exports = router;