const express = require("express");
const router = express.Router();
const m = require("../middlewares");
const {
    executeQuery,
    sendRequest
} = require("../util");

router.get("/all", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

router.get("/search", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

router.post("/", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

router.put("/:id", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

router.delete("/:id", async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

router.get("/detail/:id", m.cekBarangAda, async function (req, res) {
    return res.status(501).send("fungsi belum dibuat");
});

module.exports = router;