const express = require("express");
const router = express.Router();
const m = require("../middlewares");
const { executeQuery, sendRequest } = require("../util");

router.post("/", async function(req, res){
    return res.status(501).send("fungsi belum dibuat");
});

router.put("/", async function(req, res){
    return res.status(501).send("fungsi belum dibuat");
});

router.delete("/", async function(req, res){
    return res.status(501).send("fungsi belum dibuat");
});

router.delete("/clear", async function(req, res){
    return res.status(501).send("fungsi belum dibuat");
});

module.exports = router;