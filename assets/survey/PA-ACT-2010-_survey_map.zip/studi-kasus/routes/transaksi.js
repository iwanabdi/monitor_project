const express = require("express");
const router = express.Router();
const m = require("../middlewares");
const { executeQuery, sendRequest } = require("../util");

router.get("/", async function(req, res){
    return res.status(501).send("fungsi belum dibuat");
});

router.post("/checkout", async function(req, res){
    return res.status(501).send("fungsi belum dibuat");
});

module.exports = router;