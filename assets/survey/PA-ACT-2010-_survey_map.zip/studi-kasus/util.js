const request = require("request");
const mysql = require("mysql");

const pool = mysql.createPool({
    host: "localhost",
    database: "soaifm20201olshop",
    user: "root",
    password: "",
});

function getConnection() {
    return new Promise(function (resolve, reject) {
        pool.getConnection(function (err, conn) {
            if (err) {
                reject(err);
            } else {
                resolve(conn);
            }
        });
    });
}

async function executeQuery(query) {
    return new Promise(async function (resolve, reject) {
        const conn = await getConnection();
        conn.query(query, function (err, result) {
            conn.release();
            if (err) {
                reject(err);
            } else {
                resolve(result);
            }
        });
    });
}

function sendRequest(options) {
    return new Promise(function (resolve, reject) {
        request(options, function (error, response, body) {
            if (error){
                reject(error);
            }
            else{
                resolve({
                    response:response,
                    body:body
                });
            }
        });
    });
}

module.exports = {
    "executeQuery":executeQuery,
    "sendRequest":sendRequest
}